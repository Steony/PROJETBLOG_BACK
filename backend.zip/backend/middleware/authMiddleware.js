const jwt = require('jsonwebtoken');
const User = require('../models/user'); 

const authenticate = (req, res, next) => {
  // Récupérer le token du header Authorization
  const token = req.header('Authorization')?.replace('Bearer ', '');
  if (!token) {
    return res.status(401).json({ message: 'Accès refusé, token manquant.' });
  }

  // Vérifier le token avec la clé secrète
  jwt.verify(token, process.env.JWT_SECRET, async (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Token invalide.' });
    }

    // Ajouter l'utilisateur au request
    req.userId = user.id;  // Changer ici pour req.userId au lieu de req.user pour faciliter l'accès au userId
    try {
      const foundUser = await User.findById(user.id);
      if (!foundUser) {
        return res.status(404).json({ message: 'Utilisateur non trouvé.' });
      }
    } catch (error) {
      return res.status(500).json({ message: 'Erreur serveur.' });
    }

    next();
  });
};

module.exports = authenticate;
