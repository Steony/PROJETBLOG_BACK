require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors"); 
const app = express();

const usersRouter = require("./routes/usersRouter");
const postsRouter = require("./routes/postsRouter");

app.use(cors({
  origin: '*', 
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],  
}));

app.use(express.json());

// Connexion à MongoDB
const connectionString = process.env.CONNECTION_STRING;
mongoose
  .connect(connectionString)
  .then(() => console.log("YEAH MongoDB connecté !!! "))
  .catch((err) => console.log("Erreur MongoDB : ", err));

app.use("/Coconut/users", usersRouter);
app.use("/Coconut/posts", postsRouter);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Serveur démarré sur le port ${PORT} :D`));

module.exports = app;
